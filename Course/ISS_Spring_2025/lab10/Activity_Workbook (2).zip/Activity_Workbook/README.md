### Dependencies

- Python 3.6+ version
- fastapi and uvicorn installed