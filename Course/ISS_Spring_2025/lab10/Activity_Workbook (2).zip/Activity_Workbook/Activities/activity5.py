'''
TODO: Create a simple student management system on FastAPI using pydantic
models where you store the roll number and names of your batchmates.
You should be able to add,delete,update and show a list of all the members in
the current database.
Hint: Refer to activity4.py
'''