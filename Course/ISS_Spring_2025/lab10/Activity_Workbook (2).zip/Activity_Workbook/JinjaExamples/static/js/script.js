function showMessage() {
    alert("Hello from JavaScript!");
}
