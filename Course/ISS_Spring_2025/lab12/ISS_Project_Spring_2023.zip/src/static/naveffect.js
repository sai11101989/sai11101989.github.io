const nav=document.getElementsByTagName('a');
nav[0].addEventListener('mouseover',() => {
    nav[0].style.color='red';  
});
nav[0].addEventListener('mouseout',() => {
    nav[0].style.color='#3E8DE3';  
});
nav[1].addEventListener('mouseover',() => {
    nav[1].style.color='red';  
});
nav[1].addEventListener('mouseout',() => {
    nav[1].style.color='#3E8DE3';  
});
nav[2].addEventListener('mouseover',() => {
    nav[2].style.color='red';  
});
nav[2].addEventListener('mouseout',() => {
    nav[2].style.color='#3E8DE3';  
});
nav[3].addEventListener('mouseover',() => {
    nav[3].style.color='red';  
});
nav[3].addEventListener('mouseout',() => {
    nav[3].style.color='#3E8DE3';  
});
nav[4].addEventListener('mouseover',() => {
    nav[4].style.color='red';  
});
nav[4].addEventListener('mouseout',() => {
    nav[4].style.color='#3E8DE3';  
});