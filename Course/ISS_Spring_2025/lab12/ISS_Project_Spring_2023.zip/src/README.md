### This is how to run the App

## Requirements

- FastAPI
- Jinja2
- uvicorn

## How to Run it

- From the SRC directory

- uvicorn app:app --reload

